"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CognitiveLogo } from "@/components/cognitive-logo"
import { Brain, Clock, MessageSquare, Zap, Play } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

// Import individual assessment components
import { MemoryRecallTask } from "@/components/assessments/memory-recall-task"
import { VisuospatialTask } from "@/components/assessments/visuospatial-task"
import { VerbalFluencyTask } from "@/components/assessments/verbal-fluency-task"
import { ProcessingSpeedTask } from "@/components/assessments/processing-speed-task"

interface AssessmentData {
  memoryRecall?: any
  visuospatial?: any
  verbalFluency?: any
  processingSpeed?: any
}

const assessmentTasks = [
  {
    id: "memory-recall",
    title: "The Storyteller",
    subtitle: "Memory & Recall",
    description: "Listen to a short story and retell it in your own words",
    icon: Brain,
    estimatedTime: "5 minutes",
    color: "text-blue-600",
    bgColor: "bg-blue-50",
  },
  {
    id: "visuospatial",
    title: "The Clock Draw",
    subtitle: "Visuospatial Function",
    description: "Draw a clock showing a specific time",
    icon: Clock,
    estimatedTime: "3 minutes",
    color: "text-green-600",
    bgColor: "bg-green-50",
  },
  {
    id: "verbal-fluency",
    title: "Verbal Fluency Challenge",
    subtitle: "Executive Function",
    description: "Name as many items as possible in a given category",
    icon: MessageSquare,
    estimatedTime: "2 minutes",
    color: "text-purple-600",
    bgColor: "bg-purple-50",
  },
  {
    id: "processing-speed",
    title: "Digital Trail Making",
    subtitle: "Attention & Processing Speed",
    description: "Connect numbers and letters in alternating sequence",
    icon: Zap,
    estimatedTime: "4 minutes",
    color: "text-orange-600",
    bgColor: "bg-orange-50",
  },
]

export default function AssessmentPage() {
  const router = useRouter()
  const [currentTask, setCurrentTask] = useState<number>(-1) // -1 for overview
  const [assessmentData, setAssessmentData] = useState<AssessmentData>({})
  const [startTime, setStartTime] = useState<Date | null>(null)

  useEffect(() => {
    // Check if user has completed onboarding
    const onboardingData = localStorage.getItem("cognitiveOnboarding")
    if (!onboardingData) {
      router.push("/onboarding")
      return
    }
    setStartTime(new Date())
  }, [router])

  const handleTaskComplete = (taskId: string, data: any) => {
    setAssessmentData((prev) => ({
      ...prev,
      [taskId.replace("-", "")]: data,
    }))

    // Move to next task or results
    if (currentTask < assessmentTasks.length - 1) {
      setCurrentTask(currentTask + 1)
    } else {
      // All tasks completed, save data and go to results
      const finalData = {
        ...assessmentData,
        [taskId.replace("-", "")]: data,
        completedAt: new Date().toISOString(),
        totalTime: startTime ? Date.now() - startTime.getTime() : 0,
      }
      localStorage.setItem("cognitiveAssessmentData", JSON.stringify(finalData))
      router.push("/results")
    }
  }

  const startAssessment = () => {
    setCurrentTask(0)
  }

  const completedTasks = Object.keys(assessmentData).length
  const progressPercentage = (completedTasks / assessmentTasks.length) * 100

  // Overview screen
  if (currentTask === -1) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card/50 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <CognitiveLogo className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-lg font-semibold text-foreground">CogNitive</h1>
                <p className="text-xs text-muted-foreground">Cognitive Assessment</p>
              </div>
            </Link>
            <div className="text-sm text-muted-foreground">Total Time: ~15 minutes</div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Welcome Section */}
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Brain className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Ready to Begin Your Assessment?</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              You'll complete four engaging tasks designed to evaluate different aspects of cognitive function. Take
              your time and do your best on each task.
            </p>
            <div className="bg-primary/5 border border-primary/20 p-4 rounded-lg max-w-2xl mx-auto">
              <p className="text-sm text-muted-foreground">
                <strong>Important:</strong> Find a quiet space where you won't be interrupted. Make sure your device's
                microphone is enabled for the speaking tasks.
              </p>
            </div>
          </div>

          {/* Task Overview */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {assessmentTasks.map((task, index) => {
              const IconComponent = task.icon
              return (
                <Card key={task.id} className="border-border/50 hover:border-primary/20 transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className={`w-12 h-12 ${task.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                        <IconComponent className={`w-6 h-6 ${task.color}`} />
                      </div>
                      <span className="text-sm text-muted-foreground">{task.estimatedTime}</span>
                    </div>
                    <CardTitle className="text-xl">{task.title}</CardTitle>
                    <CardDescription className="text-base">
                      <span className="font-medium text-foreground">{task.subtitle}</span>
                      <br />
                      {task.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              )
            })}
          </div>

          {/* Start Button */}
          <div className="text-center">
            <Button size="lg" onClick={startAssessment} className="text-base px-8">
              <Play className="w-5 h-5 mr-2" />
              Begin Assessment
            </Button>
            <p className="text-sm text-muted-foreground mt-4">You can pause between tasks if needed</p>
          </div>
        </div>
      </div>
    )
  }

  // Individual task screens
  const task = assessmentTasks[currentTask]
  const IconComponent = task.icon

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Progress */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <CognitiveLogo className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-lg font-semibold text-foreground">CogNitive Assessment</h1>
                <p className="text-xs text-muted-foreground">
                  Task {currentTask + 1} of {assessmentTasks.length}
                </p>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">{task.estimatedTime}</div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-medium text-foreground">{task.title}</span>
              <span className="text-muted-foreground">{Math.round(progressPercentage)}% Complete</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
        </div>
      </header>

      {/* Task Content */}
      <div className="container mx-auto px-4 py-8">
        {currentTask === 0 && <MemoryRecallTask onComplete={(data) => handleTaskComplete("memory-recall", data)} />}
        {currentTask === 1 && <VisuospatialTask onComplete={(data) => handleTaskComplete("visuospatial", data)} />}
        {currentTask === 2 && <VerbalFluencyTask onComplete={(data) => handleTaskComplete("verbal-fluency", data)} />}
        {currentTask === 3 && (
          <ProcessingSpeedTask onComplete={(data) => handleTaskComplete("processing-speed", data)} />
        )}
      </div>
    </div>
  )
}
