"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { CognitiveLogo } from "@/components/cognitive-logo"
import {
  Brain,
  Clock,
  MessageSquare,
  Zap,
  Download,
  Share2,
  AlertTriangle,
  CheckCircle,
  Info,
  TrendingUp,
  FileText,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface AssessmentResults {
  memoryRecall?: any
  visuospatial?: any
  verbalFluency?: any
  processingSpeed?: any
  completedAt: string
  totalTime: number
}

interface RiskAnalysis {
  overallRisk: number
  riskLevel: "Low" | "Moderate" | "High"
  riskColor: string
  taskScores: {
    memoryRecall: number
    visuospatial: number
    verbalFluency: number
    processingSpeed: number
  }
  recommendations: string[]
  strengths: string[]
  concerns: string[]
}

export default function ResultsPage() {
  const router = useRouter()
  const [results, setResults] = useState<AssessmentResults | null>(null)
  const [onboardingData, setOnboardingData] = useState<any>(null)
  const [riskAnalysis, setRiskAnalysis] = useState<RiskAnalysis | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Load assessment data
    const assessmentData = localStorage.getItem("cognitiveAssessmentData")
    const onboarding = localStorage.getItem("cognitiveOnboarding")

    if (!assessmentData || !onboarding) {
      router.push("/")
      return
    }

    const parsedResults = JSON.parse(assessmentData)
    const parsedOnboarding = JSON.parse(onboarding)

    setResults(parsedResults)
    setOnboardingData(parsedOnboarding)

    // Analyze results
    const analysis = analyzeResults(parsedResults, parsedOnboarding)
    setRiskAnalysis(analysis)
    setLoading(false)
  }, [router])

  const analyzeResults = (assessmentData: AssessmentResults, demographic: any): RiskAnalysis => {
    // Simplified risk analysis algorithm
    const scores = {
      memoryRecall: calculateMemoryScore(assessmentData.memoryRecall),
      visuospatial: calculateVisuospatialScore(assessmentData.visuospatial),
      verbalFluency: calculateVerbalFluencyScore(assessmentData.verbalFluency),
      processingSpeed: calculateProcessingSpeedScore(assessmentData.processingSpeed),
    }

    // Calculate weighted overall risk (1-10 scale)
    const overallRisk =
      scores.memoryRecall * 0.3 +
      scores.visuospatial * 0.25 +
      scores.verbalFluency * 0.25 +
      scores.processingSpeed * 0.2

    let riskLevel: "Low" | "Moderate" | "High"
    let riskColor: string

    if (overallRisk <= 3) {
      riskLevel = "Low"
      riskColor = "text-green-600"
    } else if (overallRisk <= 6) {
      riskLevel = "Moderate"
      riskColor = "text-yellow-600"
    } else {
      riskLevel = "High"
      riskColor = "text-red-600"
    }

    const recommendations = generateRecommendations(scores, riskLevel, demographic)
    const strengths = identifyStrengths(scores)
    const concerns = identifyConcerns(scores)

    return {
      overallRisk,
      riskLevel,
      riskColor,
      taskScores: scores,
      recommendations,
      strengths,
      concerns,
    }
  }

  const calculateMemoryScore = (data: any): number => {
    if (!data) return 5
    // Simplified scoring based on recall completeness
    const writtenLength = data.writtenRecall?.length || 0
    const hasAudio = data.audioRecall !== null
    return Math.min(10, Math.max(1, writtenLength / 50 + (hasAudio ? 2 : 0)))
  }

  const calculateVisuospatialScore = (data: any): number => {
    if (!data) return 5
    // Simplified scoring based on completion time and drawing data
    const hasDrawing = data.drawingData && data.drawingData.length > 0
    const completionTime = data.duration || 0
    const timeScore = completionTime < 180000 ? 8 : completionTime < 300000 ? 6 : 4
    return hasDrawing ? timeScore : 2
  }

  const calculateVerbalFluencyScore = (data: any): number => {
    if (!data) return 5
    const wordCount = data.totalWords || 0
    // Age-adjusted norms (simplified)
    if (wordCount >= 15) return 9
    if (wordCount >= 12) return 7
    if (wordCount >= 8) return 5
    if (wordCount >= 5) return 3
    return 1
  }

  const calculateProcessingSpeedScore = (data: any): number => {
    if (!data) return 5
    const completed = data.completed || false
    const errors = data.errors || 0
    const duration = data.duration || 0

    if (!completed) return 2
    if (duration < 60000 && errors <= 1) return 9
    if (duration < 90000 && errors <= 2) return 7
    if (duration < 120000 && errors <= 3) return 5
    return 3
  }

  const generateRecommendations = (scores: any, riskLevel: string, demographic: any): string[] => {
    const recommendations = []

    if (riskLevel === "High") {
      recommendations.push("Consult with a healthcare professional for comprehensive cognitive evaluation")
      recommendations.push("Consider scheduling a follow-up assessment in 3-6 months")
    } else if (riskLevel === "Moderate") {
      recommendations.push("Discuss results with your primary care physician")
      recommendations.push("Consider lifestyle modifications to support cognitive health")
    } else {
      recommendations.push("Continue maintaining healthy lifestyle habits")
      recommendations.push("Consider annual cognitive screening")
    }

    if (scores.memoryRecall < 5) {
      recommendations.push("Practice memory exercises and maintain social engagement")
    }
    if (scores.processingSpeed < 5) {
      recommendations.push("Engage in activities that challenge processing speed and attention")
    }

    return recommendations
  }

  const identifyStrengths = (scores: any): string[] => {
    const strengths = []
    if (scores.memoryRecall >= 7) strengths.push("Strong memory and recall abilities")
    if (scores.visuospatial >= 7) strengths.push("Good visuospatial and executive function")
    if (scores.verbalFluency >= 7) strengths.push("Excellent verbal fluency and language skills")
    if (scores.processingSpeed >= 7) strengths.push("Fast processing speed and attention")
    return strengths
  }

  const identifyConcerns = (scores: any): string[] => {
    const concerns = []
    if (scores.memoryRecall < 4) concerns.push("Memory and recall performance below expected range")
    if (scores.visuospatial < 4) concerns.push("Visuospatial function may need attention")
    if (scores.verbalFluency < 4) concerns.push("Verbal fluency below typical performance")
    if (scores.processingSpeed < 4) concerns.push("Processing speed slower than expected")
    return concerns
  }

  const downloadReport = () => {
    // Generate PDF report (simplified - would use a PDF library in production)
    const reportData = {
      results,
      onboardingData,
      riskAnalysis,
      generatedAt: new Date().toISOString(),
    }

    const dataStr = JSON.stringify(reportData, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `cognitive-assessment-report-${new Date().toISOString().split("T")[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  if (loading || !results || !riskAnalysis) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <CognitiveLogo className="w-16 h-16 text-primary mx-auto mb-4 animate-pulse" />
          <p className="text-muted-foreground">Analyzing your results...</p>
        </div>
      </div>
    )
  }

  const taskDetails = [
    {
      id: "memory-recall",
      title: "Memory & Recall",
      icon: Brain,
      score: riskAnalysis.taskScores.memoryRecall,
      data: results.memoryRecall,
      description: "Story comprehension and recall ability",
    },
    {
      id: "visuospatial",
      title: "Visuospatial Function",
      icon: Clock,
      score: riskAnalysis.taskScores.visuospatial,
      data: results.visuospatial,
      description: "Spatial awareness and executive function",
    },
    {
      id: "verbal-fluency",
      title: "Verbal Fluency",
      icon: MessageSquare,
      score: riskAnalysis.taskScores.verbalFluency,
      data: results.verbalFluency,
      description: "Language processing and executive function",
    },
    {
      id: "processing-speed",
      title: "Processing Speed",
      icon: Zap,
      score: riskAnalysis.taskScores.processingSpeed,
      data: results.processingSpeed,
      description: "Attention and cognitive processing speed",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <CognitiveLogo className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-lg font-semibold text-foreground">CogNitive</h1>
              <p className="text-xs text-muted-foreground">Assessment Results</p>
            </div>
          </Link>
          <div className="flex items-center gap-2">
            <Button
              onClick={downloadReport}
              variant="outline"
              size="sm"
              className="flex items-center gap-2 bg-transparent"
            >
              <Download className="w-4 h-4" />
              Download Report
            </Button>
            <Button variant="outline" size="sm" className="flex items-center gap-2 bg-transparent">
              <Share2 className="w-4 h-4" />
              Share
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Overall Risk Assessment */}
        <Card className="mb-8">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-10 h-10 text-primary" />
            </div>
            <CardTitle className="text-3xl">Your Cognitive Assessment Results</CardTitle>
            <CardDescription className="text-base">
              Completed on {new Date(results.completedAt).toLocaleDateString()} • Total time:{" "}
              {Math.round(results.totalTime / 60000)} minutes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="mb-4">
                <div className={`text-6xl font-bold ${riskAnalysis.riskColor} mb-2`}>
                  {riskAnalysis.overallRisk.toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground mb-2">Dementia Risk Index (1-10 scale)</div>
                <Badge
                  variant={riskAnalysis.riskLevel === "Low" ? "default" : "destructive"}
                  className="text-base px-4 py-1"
                >
                  {riskAnalysis.riskLevel} Risk
                </Badge>
              </div>
              <Progress value={(10 - riskAnalysis.overallRisk) * 10} className="h-3 mb-4" />
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              {riskAnalysis.strengths.length > 0 && (
                <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <h3 className="font-semibold text-green-800">Strengths</h3>
                  </div>
                  <ul className="text-sm text-green-700 space-y-1">
                    {riskAnalysis.strengths.map((strength, index) => (
                      <li key={index}>• {strength}</li>
                    ))}
                  </ul>
                </div>
              )}

              {riskAnalysis.concerns.length > 0 && (
                <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    <h3 className="font-semibold text-yellow-800">Areas of Concern</h3>
                  </div>
                  <ul className="text-sm text-yellow-700 space-y-1">
                    {riskAnalysis.concerns.map((concern, index) => (
                      <li key={index}>• {concern}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Info className="w-5 h-5 text-blue-600" />
                  <h3 className="font-semibold text-blue-800">Recommendations</h3>
                </div>
                <ul className="text-sm text-blue-700 space-y-1">
                  {riskAnalysis.recommendations.slice(0, 3).map((rec, index) => (
                    <li key={index}>• {rec}</li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Task Breakdown */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {taskDetails.map((task) => {
            const IconComponent = task.icon
            const scorePercentage = (task.score / 10) * 100

            return (
              <Card key={task.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <IconComponent className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{task.title}</CardTitle>
                        <CardDescription>{task.description}</CardDescription>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{task.score.toFixed(1)}</div>
                      <div className="text-xs text-muted-foreground">/ 10</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Progress value={scorePercentage} className="h-2 mb-4" />
                  <div className="text-sm text-muted-foreground">
                    {task.id === "verbal-fluency" && task.data && (
                      <span>Words generated: {task.data.totalWords || 0}</span>
                    )}
                    {task.id === "processing-speed" && task.data && (
                      <span>
                        Completion: {task.data.completed ? "Yes" : "No"} • Errors: {task.data.errors || 0}
                      </span>
                    )}
                    {task.id === "memory-recall" && task.data && (
                      <span>Response provided: {task.data.writtenRecall ? "Written" : "Audio"}</span>
                    )}
                    {task.id === "visuospatial" && task.data && (
                      <span>Clock drawing: {task.data.drawingData ? "Completed" : "Not completed"}</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Detailed Recommendations */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Detailed Recommendations
            </CardTitle>
            <CardDescription>
              Based on your assessment results and demographic profile, here are personalized recommendations:
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {riskAnalysis.recommendations.map((recommendation, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-primary">{index + 1}</span>
                  </div>
                  <p className="text-sm text-foreground">{recommendation}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Important Disclaimer */}
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-yellow-800 mb-2">Important Medical Disclaimer</h3>
                <p className="text-sm text-yellow-700 mb-4">
                  This assessment is a screening tool designed to identify potential cognitive concerns. It is{" "}
                  <strong>not a medical diagnosis</strong> and should not replace professional medical evaluation.
                </p>
                <p className="text-sm text-yellow-700">
                  If you have concerns about your cognitive health or if this assessment indicates moderate to high
                  risk, please consult with a qualified healthcare provider for comprehensive evaluation and appropriate
                  care.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="text-center mt-8 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={downloadReport} size="lg" className="flex items-center gap-2">
              <Download className="w-5 h-5" />
              Download Full Report
            </Button>
            <Button variant="outline" size="lg" className="flex items-center gap-2 bg-transparent">
              <Share2 className="w-5 h-5" />
              Share with Doctor
            </Button>
            <Link href="/onboarding">
              <Button variant="outline" size="lg">
                Take Assessment Again
              </Button>
            </Link>
          </div>
          <p className="text-sm text-muted-foreground">
            Questions about your results?{" "}
            <Link href="mailto:support@cognitive.app" className="text-primary hover:underline">
              Contact our support team
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
