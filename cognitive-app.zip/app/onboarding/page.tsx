"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { CognitiveLogo } from "@/components/cognitive-logo"
import { ArrowLeft, ArrowRight, Globe, Shield, Clock } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface OnboardingData {
  language: string
  age: string
  gender: string
  education: string
  primaryLanguage: string
  consentGiven: boolean
  privacyAccepted: boolean
}

export default function OnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [data, setData] = useState<OnboardingData>({
    language: "",
    age: "",
    gender: "",
    education: "",
    primaryLanguage: "",
    consentGiven: false,
    privacyAccepted: false,
  })

  const totalSteps = 4

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1)
    } else {
      // Save onboarding data and proceed to assessment
      localStorage.setItem("cognitiveOnboarding", JSON.stringify(data))
      router.push("/assessment")
    }
  }

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const canProceed = () => {
    switch (step) {
      case 1:
        return data.language !== ""
      case 2:
        return data.age !== "" && data.gender !== ""
      case 3:
        return data.education !== "" && data.primaryLanguage !== ""
      case 4:
        return data.consentGiven && data.privacyAccepted
      default:
        return false
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <CognitiveLogo className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-lg font-semibold text-foreground">CogNitive</h1>
              <p className="text-xs text-muted-foreground">Setup Your Profile</p>
            </div>
          </Link>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>
              Step {step} of {totalSteps}
            </span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-foreground">Profile Setup</span>
            <span className="text-sm text-muted-foreground">{Math.round((step / totalSteps) * 100)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1: Language Selection */}
        {step === 1 && (
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Choose Your Language</CardTitle>
              <CardDescription>
                Select your preferred language for the assessment. This helps us provide culturally relevant content and
                accurate analysis.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="language">Assessment Language</Label>
                <Select value={data.language} onValueChange={(value) => setData({ ...data, language: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your preferred language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="spanish">Español (Spanish)</SelectItem>
                    <SelectItem value="french">Français (French)</SelectItem>
                    <SelectItem value="german">Deutsch (German)</SelectItem>
                    <SelectItem value="italian">Italiano (Italian)</SelectItem>
                    <SelectItem value="portuguese">Português (Portuguese)</SelectItem>
                    <SelectItem value="mandarin">中文 (Mandarin)</SelectItem>
                    <SelectItem value="hindi">हिन्दी (Hindi)</SelectItem>
                    <SelectItem value="arabic">العربية (Arabic)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  <Shield className="w-4 h-4 inline mr-2" />
                  Your language preference helps us provide more accurate cognitive assessments by using culturally
                  appropriate content and establishing proper baselines.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Basic Demographics */}
        {step === 2 && (
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary">2</span>
              </div>
              <CardTitle className="text-2xl">Basic Information</CardTitle>
              <CardDescription>
                This information helps us establish personalized baselines for your cognitive assessment. All data is
                kept confidential and secure.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age Range</Label>
                  <Select value={data.age} onValueChange={(value) => setData({ ...data, age: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select age range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="18-29">18-29 years</SelectItem>
                      <SelectItem value="30-39">30-39 years</SelectItem>
                      <SelectItem value="40-49">40-49 years</SelectItem>
                      <SelectItem value="50-59">50-59 years</SelectItem>
                      <SelectItem value="60-69">60-69 years</SelectItem>
                      <SelectItem value="70-79">70-79 years</SelectItem>
                      <SelectItem value="80+">80+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Gender</Label>
                  <RadioGroup
                    value={data.gender}
                    onValueChange={(value) => setData({ ...data, gender: value })}
                    className="flex flex-col space-y-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male">Male</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female">Female</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other">Other</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="prefer-not-to-say" id="prefer-not-to-say" />
                      <Label htmlFor="prefer-not-to-say">Prefer not to say</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Education & Language Background */}
        {step === 3 && (
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary">3</span>
              </div>
              <CardTitle className="text-2xl">Education & Language</CardTitle>
              <CardDescription>
                Your educational background and native language help us better interpret your assessment results.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="education">Highest Level of Education</Label>
                <Select value={data.education} onValueChange={(value) => setData({ ...data, education: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select education level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="elementary">Elementary School</SelectItem>
                    <SelectItem value="middle">Middle School</SelectItem>
                    <SelectItem value="high-school">High School</SelectItem>
                    <SelectItem value="some-college">Some College</SelectItem>
                    <SelectItem value="associates">Associate's Degree</SelectItem>
                    <SelectItem value="bachelors">Bachelor's Degree</SelectItem>
                    <SelectItem value="masters">Master's Degree</SelectItem>
                    <SelectItem value="doctorate">Doctorate/PhD</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="primaryLanguage">Native/Primary Language</Label>
                <Select
                  value={data.primaryLanguage}
                  onValueChange={(value) => setData({ ...data, primaryLanguage: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your native language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="spanish">Spanish</SelectItem>
                    <SelectItem value="french">French</SelectItem>
                    <SelectItem value="german">German</SelectItem>
                    <SelectItem value="italian">Italian</SelectItem>
                    <SelectItem value="portuguese">Portuguese</SelectItem>
                    <SelectItem value="mandarin">Mandarin Chinese</SelectItem>
                    <SelectItem value="hindi">Hindi</SelectItem>
                    <SelectItem value="arabic">Arabic</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  <Clock className="w-4 h-4 inline mr-2" />
                  This information helps us adjust scoring algorithms to account for cultural and educational
                  differences, ensuring more accurate results.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Consent & Privacy */}
        {step === 4 && (
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Consent & Privacy</CardTitle>
              <CardDescription>
                Please review and accept our terms to proceed with your cognitive assessment.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="consent"
                    checked={data.consentGiven}
                    onCheckedChange={(checked) => setData({ ...data, consentGiven: checked as boolean })}
                  />
                  <div className="space-y-1">
                    <Label
                      htmlFor="consent"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Assessment Consent
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      I understand that this is a screening tool and not a medical diagnosis. I consent to participate
                      in the cognitive assessment and understand that results should be discussed with a healthcare
                      professional.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="privacy"
                    checked={data.privacyAccepted}
                    onCheckedChange={(checked) => setData({ ...data, privacyAccepted: checked as boolean })}
                  />
                  <div className="space-y-1">
                    <Label
                      htmlFor="privacy"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Privacy Policy
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      I have read and accept the{" "}
                      <Link href="/privacy" className="text-primary hover:underline">
                        Privacy Policy
                      </Link>
                      . I understand how my data will be used and that all information is kept confidential and secure.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-primary/5 border border-primary/20 p-4 rounded-lg">
                <h4 className="font-medium text-foreground mb-2">Important Disclaimer</h4>
                <p className="text-sm text-muted-foreground">
                  CogNitive is a screening tool designed to identify potential cognitive concerns. It is not a
                  substitute for professional medical evaluation. If you have concerns about your cognitive health,
                  please consult with a qualified healthcare provider.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === 1}
            className="flex items-center gap-2 bg-transparent"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>

          <Button onClick={handleNext} disabled={!canProceed()} className="flex items-center gap-2">
            {step === totalSteps ? "Start Assessment" : "Continue"}
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Help Text */}
        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Need help? Contact our support team at{" "}
            <Link href="mailto:support@cognitive.app" className="text-primary hover:underline">
              support@cognitive.app
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
