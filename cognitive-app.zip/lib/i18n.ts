export interface Translation {
  [key: string]: string | Translation
}

export const translations: { [key: string]: Translation } = {
  english: {
    common: {
      continue: "Continue",
      back: "Back",
      complete: "Complete",
      start: "Start",
      loading: "Loading...",
      error: "Error",
      success: "Success",
      cancel: "Cancel",
      save: "Save",
      next: "Next",
      previous: "Previous",
      close: "Close",
    },
    navigation: {
      home: "Home",
      assessment: "Assessment",
      results: "Results",
      about: "About",
      contact: "Contact",
      privacy: "Privacy Policy",
      terms: "Terms of Service",
    },
    home: {
      title: "Early Detection for Better Outcomes",
      subtitle:
        "AI-powered cognitive screening that analyzes speech, behavior, and cognitive patterns to detect early signs of dementia.",
      startAssessment: "Start Assessment",
      learnMore: "Learn More",
      features: {
        title: "Comprehensive Cognitive Assessment",
        subtitle:
          "Our AI-powered assessment suite evaluates multiple cognitive domains through engaging, gamified tasks.",
        memoryTitle: "Memory & Recall",
        memoryDesc: "Story-based memory assessment analyzing information retention and semantic coherence.",
        visuospatialTitle: "Visuospatial Function",
        visuospatialDesc: "Digital clock drawing test evaluating spatial awareness and executive function.",
        verbalTitle: "Verbal Fluency",
        verbalDesc: "Category-based word generation measuring executive function and language processing.",
        processingTitle: "Processing Speed",
        processingDesc: "Digital trail-making test assessing attention, cognitive flexibility, and processing speed.",
      },
    },
    onboarding: {
      title: "Setup Your Profile",
      step1: {
        title: "Choose Your Language",
        description:
          "Select your preferred language for the assessment. This helps us provide culturally relevant content and accurate analysis.",
        languageLabel: "Assessment Language",
        languagePlaceholder: "Select your preferred language",
      },
      step2: {
        title: "Basic Information",
        description:
          "This information helps us establish personalized baselines for your cognitive assessment. All data is kept confidential and secure.",
        ageLabel: "Age Range",
        agePlaceholder: "Select age range",
        genderLabel: "Gender",
        male: "Male",
        female: "Female",
        other: "Other",
        preferNotToSay: "Prefer not to say",
      },
      step3: {
        title: "Education & Language",
        description:
          "Your educational background and native language help us better interpret your assessment results.",
        educationLabel: "Highest Level of Education",
        educationPlaceholder: "Select education level",
        primaryLanguageLabel: "Native/Primary Language",
        primaryLanguagePlaceholder: "Select your native language",
      },
      step4: {
        title: "Consent & Privacy",
        description: "Please review and accept our terms to proceed with your cognitive assessment.",
        consentTitle: "Assessment Consent",
        consentText:
          "I understand that this is a screening tool and not a medical diagnosis. I consent to participate in the cognitive assessment and understand that results should be discussed with a healthcare professional.",
        privacyTitle: "Privacy Policy",
        privacyText:
          "I have read and accept the Privacy Policy. I understand how my data will be used and that all information is kept confidential and secure.",
        disclaimer:
          "CogNitive is a screening tool designed to identify potential cognitive concerns. It is not a substitute for professional medical evaluation.",
      },
    },
    assessment: {
      title: "Cognitive Assessment",
      readyTitle: "Ready to Begin Your Assessment?",
      readySubtitle:
        "You'll complete four engaging tasks designed to evaluate different aspects of cognitive function. Take your time and do your best on each task.",
      importantNote:
        "Find a quiet space where you won't be interrupted. Make sure your device's microphone is enabled for the speaking tasks.",
      beginAssessment: "Begin Assessment",
      pauseNote: "You can pause between tasks if needed",
      tasks: {
        memoryRecall: {
          title: "The Storyteller",
          subtitle: "Memory & Recall Assessment",
          instructions:
            "You will hear a short story about everyday activities. Listen carefully and try to remember as many details as possible. After the story ends, you'll retell it in your own words.",
          tip: "Focus on the main events, characters, and important details. Don't worry about remembering every single word.",
          listenTitle: "Listen Carefully",
          listenDesc: "The story is playing. Pay attention to the details.",
          recallTitle: "Now Retell the Story",
          recallDesc: "Share what you remember in your own words",
          writePlaceholder: "Tell me what you remember about the story. Include as many details as you can recall...",
          recordResponse: "Record Response",
          startRecording: "Start Recording",
          stopRecording: "Stop Recording",
          recordingComplete: "Recording completed",
        },
        visuospatial: {
          title: "The Clock Draw",
          subtitle: "Visuospatial Function Assessment",
          instructions:
            "You will draw a clock face on the canvas provided. Include all 12 numbers in their correct positions. Draw the hands to show the specified time.",
          remember: "Draw a complete clock with numbers 1-12, and set the hands correctly.",
          drawTitle: "Draw a Clock",
          clearRestart: "Clear & Restart",
          targetTime: "Target Time",
          includeNumbers: "Make sure to include all numbers 1-12 and position the hands correctly",
        },
        verbalFluency: {
          title: "Verbal Fluency Challenge",
          subtitle: "Executive Function Assessment",
          instructions:
            "You have 60 seconds to name as many items as possible in the given category. Type each word and press Enter to add it to your list.",
          selectCategory: "Select Category:",
          selected: "Selected",
          nameMany: "Name as many {category} as you can in 60 seconds!",
          startChallenge: "Start Challenge",
          timeRemaining: "Time remaining:",
          yourWords: "Your Words",
          wordsWillAppear: "Your words will appear here...",
          timeUp: "Time's Up!",
          greatJob: "Great job! You named {count} {category}",
          finalList: "Your Final List:",
        },
        processingSpeed: {
          title: "Digital Trail Making",
          subtitle: "Attention & Processing Speed Assessment",
          instructions:
            "You will see numbers (1-8) and letters (A-H) scattered on the screen. Click them in alternating order: 1 → A → 2 → B → 3 → C → 4 → D → 5 → E → 6 → F → 7 → G → 8 → H",
          remember: "Alternate between numbers and letters in sequence. Speed and accuracy are both important!",
          startTrail: "Start Trail Making",
          click: "Click:",
          errors: "Errors:",
          nextSequence: "Next in sequence:",
          restart: "Restart",
          currentTarget: "Current Target:",
          progress: "Progress:",
          trailCompleted: "Trail Completed!",
          excellentWork: "Excellent work! You completed the trail making task.",
          completionTime: "Completion Time",
        },
      },
    },
    results: {
      title: "Your Cognitive Assessment Results",
      analyzingResults: "Analyzing your results...",
      riskIndex: "Dementia Risk Index (1-10 scale)",
      lowRisk: "Low Risk",
      moderateRisk: "Moderate Risk",
      highRisk: "High Risk",
      strengths: "Strengths",
      concerns: "Areas of Concern",
      recommendations: "Recommendations",
      taskBreakdown: "Task Breakdown",
      detailedRecommendations: "Detailed Recommendations",
      disclaimer: {
        title: "Important Medical Disclaimer",
        text1:
          "This assessment is a screening tool designed to identify potential cognitive concerns. It is not a medical diagnosis and should not replace professional medical evaluation.",
        text2:
          "If you have concerns about your cognitive health or if this assessment indicates moderate to high risk, please consult with a qualified healthcare provider for comprehensive evaluation and appropriate care.",
      },
      downloadReport: "Download Full Report",
      shareWithDoctor: "Share with Doctor",
      takeAgain: "Take Assessment Again",
      questionsContact: "Questions about your results? Contact our support team",
    },
  },
  spanish: {
    common: {
      continue: "Continuar",
      back: "Atrás",
      complete: "Completar",
      start: "Comenzar",
      loading: "Cargando...",
      error: "Error",
      success: "Éxito",
      cancel: "Cancelar",
      save: "Guardar",
      next: "Siguiente",
      previous: "Anterior",
      close: "Cerrar",
    },
    navigation: {
      home: "Inicio",
      assessment: "Evaluación",
      results: "Resultados",
      about: "Acerca de",
      contact: "Contacto",
      privacy: "Política de Privacidad",
      terms: "Términos de Servicio",
    },
    home: {
      title: "Detección Temprana para Mejores Resultados",
      subtitle:
        "Evaluación cognitiva impulsada por IA que analiza el habla, comportamiento y patrones cognitivos para detectar signos tempranos de demencia.",
      startAssessment: "Comenzar Evaluación",
      learnMore: "Saber Más",
      features: {
        title: "Evaluación Cognitiva Integral",
        subtitle:
          "Nuestro conjunto de evaluaciones impulsadas por IA evalúa múltiples dominios cognitivos a través de tareas atractivas y gamificadas.",
        memoryTitle: "Memoria y Recuerdo",
        memoryDesc:
          "Evaluación de memoria basada en historias que analiza la retención de información y coherencia semántica.",
        visuospatialTitle: "Función Visuoespacial",
        visuospatialDesc: "Prueba digital de dibujo de reloj que evalúa la conciencia espacial y función ejecutiva.",
        verbalTitle: "Fluidez Verbal",
        verbalDesc: "Generación de palabras por categorías que mide la función ejecutiva y procesamiento del lenguaje.",
        processingTitle: "Velocidad de Procesamiento",
        processingDesc:
          "Prueba digital de seguimiento de senderos que evalúa atención, flexibilidad cognitiva y velocidad de procesamiento.",
      },
    },
    // ... Additional Spanish translations would continue here
  },
  // Additional languages would be added here
}

export function getTranslation(language: string, key: string): string {
  const keys = key.split(".")
  let current: any = translations[language] || translations.english

  for (const k of keys) {
    current = current?.[k]
    if (current === undefined) {
      // Fallback to English if translation not found
      current = translations.english
      for (const fallbackKey of keys) {
        current = current?.[fallbackKey]
        if (current === undefined) return key
      }
      break
    }
  }

  return typeof current === "string" ? current : key
}

export function formatTranslation(
  language: string,
  key: string,
  params: { [key: string]: string | number } = {},
): string {
  let translation = getTranslation(language, key)

  Object.entries(params).forEach(([param, value]) => {
    translation = translation.replace(`{${param}}`, String(value))
  })

  return translation
}
