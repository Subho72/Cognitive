let currentLanguage = "en"
let currentPage = "home"
let navigationHistory = []

function goToHome() {
  document.querySelector(".container").style.display = "block"
  const pages = document.querySelectorAll(".page")
  pages.forEach((page) => page.classList.remove("active"))
  currentPage = "home"
  navigationHistory = []
}

function goBack() {
  if (navigationHistory.length > 0) {
    const previousPage = navigationHistory.pop()
    if (previousPage === "home") {
      goToHome()
    } else {
      showPage(previousPage)
    }
  } else {
    goToHome()
  }
}

function changeLanguage(language) {
  currentLanguage = language
  translatePage(language)
  localStorage.setItem("preferredLanguage", language)

  if (language === "hi") {
    document.title = "CogNitive - प्रारंभिक डिमेंशिया का पता लगाना"
  } else {
    document.title = "CogNitive - Early Dementia Detection"
  }
}

function translatePage(lang) {
  const elements = document.querySelectorAll("[data-translate]")
  elements.forEach((element) => {
    const key = element.getAttribute("data-translate")
    const translation = getTranslation(key, lang)
    if (translation) {
      element.textContent = translation
    }
  })
}

function getTranslation(key, lang) {
  const translations = {
    en: {
      "header.signin": "Sign In",
      "hero.title": "AI-Powered Cognitive Assessment",
      "hero.subtitle": "Quick and easy cognitive screening for early dementia detection",
      "hero.cta": "Start Assessment",
      "features.title": "Four Simple Tests",
      "features.memory.title": "Memory Test",
      "features.memory.description": "Story recall assessment",
      "features.visuospatial.title": "Drawing Test",
      "features.visuospatial.description": "Clock drawing task",
      "features.verbal.title": "Word Test",
      "features.verbal.description": "Verbal fluency check",
      "features.processing.title": "Speed Test",
      "features.processing.description": "Processing speed task",
      "info.title": "How It Works",
      "info.step1": "Set up your profile",
      "info.step2": "Complete 4 quick tests",
      "info.step3": "Get your results",
      "common.back": "Back",
      "signin.title": "Sign In to CogNitive",
      "signin.email": "Email",
      "signin.password": "Password",
      "signin.submit": "Sign In",
      "signin.noAccount": "Don't have an account?",
      "signin.signUp": "Sign Up",
      "onboarding.title": "Quick Setup",
      "onboarding.age": "Age",
      "onboarding.gender": "Gender",
      "onboarding.male": "Male",
      "onboarding.female": "Female",
      "onboarding.other": "Other",
      "onboarding.education": "Education",
      "onboarding.primary": "Primary",
      "onboarding.secondary": "Secondary",
      "onboarding.higher": "Higher",
      "onboarding.continue": "Continue",
      "results.title": "Your Results",
      "results.calculating": "Calculating...",
      "results.recommendations": "Recommendations",
      "results.download": "Download Report",
      "results.sendDoctor": "Send to Doctor",
      "results.home": "Back to Home",
    },
    hi: {
      "header.signin": "साइन इन करें",
      "hero.title": "AI-संचालित संज्ञानात्मक मूल्यांकन",
      "hero.subtitle": "प्रारंभिक डिमेंशिया का पता लगाने के लिए त्वरित और आसान संज्ञानात्मक जांच",
      "hero.cta": "मूल्यांकन शुरू करें",
      "features.title": "चार सरल परीक्षण",
      "features.memory.title": "स्मृति परीक्षण",
      "features.memory.description": "कहानी याद करने का आकलन",
      "features.visuospatial.title": "चित्रकारी परीक्षण",
      "features.visuospatial.description": "घड़ी बनाने का कार्य",
      "features.verbal.title": "शब्द परीक्षण",
      "features.verbal.description": "मौखिक प्रवाहता जांच",
      "features.processing.title": "गति परीक्षण",
      "features.processing.description": "प्रसंस्करण गति कार्य",
      "info.title": "यह कैसे काम करता है",
      "info.step1": "अपनी प्रोफ़ाइल सेट करें",
      "info.step2": "4 त्वरित परीक्षण पूरे करें",
      "info.step3": "अपने परिणाम प्राप्त करें",
      "common.back": "वापस",
      "signin.title": "CogNitive में साइन इन करें",
      "signin.email": "ईमेल",
      "signin.password": "पासवर्ड",
      "signin.submit": "साइन इन करें",
      "signin.noAccount": "खाता नहीं है?",
      "signin.signUp": "साइन अप करें",
      "onboarding.title": "त्वरित सेटअप",
      "onboarding.age": "आयु",
      "onboarding.gender": "लिंग",
      "onboarding.male": "पुरुष",
      "onboarding.female": "महिला",
      "onboarding.other": "अन्य",
      "onboarding.education": "शिक्षा",
      "onboarding.primary": "प्राथमिक",
      "onboarding.secondary": "माध्यमिक",
      "onboarding.higher": "उच्चतर",
      "onboarding.continue": "जारी रखें",
      "results.title": "आपके परिणाम",
      "results.calculating": "गणना कर रहे हैं...",
      "results.recommendations": "सिफारिशें",
      "results.download": "रिपोर्ट डाउनलोड करें",
      "results.sendDoctor": "डॉक्टर को भेजें",
      "results.home": "होम पर वापस जाएं",
    },
  }
  return translations[lang]?.[key] || translations.en[key]
}

function showPage(pageId) {
  if (currentPage !== "home") {
    navigationHistory.push(currentPage)
  }

  document.querySelector(".container").style.display = "none"
  const pages = document.querySelectorAll(".page")
  pages.forEach((page) => page.classList.remove("active"))

  const targetPage = document.getElementById(pageId)
  if (targetPage) {
    targetPage.classList.add("active")
  }
  currentPage = pageId
}

function showSignIn() {
  showPage("signInPage")
}

function showSignUp() {
  // Placeholder for sign-up functionality
  alert("Sign up functionality would be implemented here")
}

function startAssessment() {
  showPage("onboardingPage")
}

function downloadReport() {
  const userData = JSON.parse(localStorage.getItem("userData") || "{}")
  const riskScore = document.getElementById("riskScore").textContent
  const riskLevel = document.getElementById("riskLevel").textContent

  const reportContent = `
COGNITIVE ASSESSMENT REPORT
===========================

Patient Information:
- Age: ${userData.age || "Not specified"}
- Gender: ${userData.gender || "Not specified"}
- Education: ${userData.education || "Not specified"}
- Assessment Date: ${new Date().toLocaleDateString()}

Assessment Results:
- Overall Risk Score: ${riskScore}/10
- Risk Level: ${riskLevel}

Test Performance:
1. Memory Assessment: Completed
   - Story recall task performed
   - Performance within normal range

2. Visuospatial Function: Completed
   - Clock drawing task performed
   - Spatial awareness assessed

3. Verbal Fluency: Completed
   - Word generation task performed
   - Language skills evaluated

4. Processing Speed: Completed
   - Trail making task performed
   - Cognitive processing assessed

Recommendations:
- Continue regular mental exercises
- Maintain social activities
- Annual screening recommended
- Consult healthcare provider if concerns arise

Note: This assessment is for screening purposes only and should not replace professional medical diagnosis.

Generated by CogNitive AI Assessment Tool
  `

  const blob = new Blob([reportContent], { type: "text/plain" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = `CogNitive_Assessment_Report_${new Date().toISOString().split("T")[0]}.txt`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

function sendToDoctor() {
  const doctors = [
    "Dr. Rajesh Kumar - Neurologist at Apollo Hospital",
    "Dr. Priya Sharma - Geriatrician at Max Healthcare",
    "Dr. Amit Patel - Psychiatrist at Fortis Hospital",
    "Dr. Sunita Reddy - Memory Specialist at AIIMS",
  ]

  const randomDoctor = doctors[Math.floor(Math.random() * doctors.length)]
  const referenceNumber = Math.random().toString(36).substr(2, 9).toUpperCase()

  alert(
    `Report sent successfully!\n\nSent to: ${randomDoctor}\nReference Number: ${referenceNumber}\nExpected Response: 2-3 business days\n\nYou will receive a confirmation email shortly.`,
  )
}

document.addEventListener("DOMContentLoaded", () => {
  // Load saved language preference
  const savedLanguage = localStorage.getItem("preferredLanguage")
  if (savedLanguage) {
    document.getElementById("languageSelect").value = savedLanguage
    changeLanguage(savedLanguage)
  }

  const signInForm = document.getElementById("signInForm")
  if (signInForm) {
    signInForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("email").value
      const password = document.getElementById("password").value

      // Simple validation and mock authentication
      if (email && password) {
        localStorage.setItem("userLoggedIn", "true")
        localStorage.setItem("userEmail", email)
        alert("Sign in successful!")
        goToHome()
      } else {
        alert("Please enter both email and password")
      }
    })
  }

  const onboardingForm = document.getElementById("onboardingForm")
  if (onboardingForm) {
    onboardingForm.addEventListener("submit", (e) => {
      e.preventDefault()

      // Save user data
      const userData = {
        age: document.getElementById("age").value,
        gender: document.getElementById("gender").value,
        education: document.getElementById("education").value,
      }

      localStorage.setItem("userData", JSON.stringify(userData))
      showPage("assessmentPage")
      initializeAssessment()
    })
  }
})

function initializeAssessment() {
  let currentTestIndex = 0
  const tests = [
    {
      name: "Memory Assessment",
      description: "Listen to this story and then retell it:",
      content: `
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Story:</strong> "Mrs. Sharma went to the market on Tuesday. She bought tomatoes, onions, and rice. On her way home, she met her neighbor who told her about a new community center opening next month."</p>
        </div>
        <textarea class="form-group input" rows="4" placeholder="Retell the story here..." id="memoryResponse"></textarea>
      `,
    },
    {
      name: "Visuospatial Function",
      description: "Draw a clock showing 3:15:",
      content: `
        <div style="background: #f8fafc; padding: 40px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <canvas id="clockCanvas" width="300" height="300" style="border: 2px solid #e2e8f0; border-radius: 8px; cursor: crosshair;"></canvas>
          <p style="margin-top: 10px; font-size: 14px; color: #64748b;">Click and drag to draw</p>
          <button type="button" onclick="clearCanvas()" style="margin-top: 10px; padding: 8px 16px; background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 4px;">Clear</button>
        </div>
      `,
    },
    {
      name: "Verbal Fluency",
      description: "Name as many animals as you can in 60 seconds:",
      content: `
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <div id="timer" style="font-size: 24px; font-weight: bold; text-align: center; margin-bottom: 20px;">60</div>
          <textarea class="form-group input" rows="4" placeholder="Type animal names here..." id="animalResponse"></textarea>
          <button type="button" onclick="startTimer()" id="startTimerBtn" style="margin-top: 10px; padding: 8px 16px; background: #10b981; color: white; border: none; border-radius: 4px;">Start Timer</button>
        </div>
      `,
    },
    {
      name: "Processing Speed",
      description: "Connect the numbers in order (1-2-3-4-5) as quickly as possible:",
      content: `
        <div style="background: #f8fafc; padding: 40px; border-radius: 8px; margin: 20px 0; position: relative; height: 300px;">
          <div class="trail-number" style="position: absolute; top: 50px; left: 50px; width: 40px; height: 40px; background: #3b82f6; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;" onclick="selectNumber(1)">1</div>
          <div class="trail-number" style="position: absolute; top: 100px; right: 80px; width: 40px; height: 40px; background: #3b82f6; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;" onclick="selectNumber(2)">2</div>
          <div class="trail-number" style="position: absolute; bottom: 120px; left: 100px; width: 40px; height: 40px; background: #3b82f6; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;" onclick="selectNumber(3)">3</div>
          <div class="trail-number" style="position: absolute; bottom: 50px; right: 50px; width: 40px; height: 40px; background: #3b82f6; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;" onclick="selectNumber(4)">4</div>
          <div class="trail-number" style="position: absolute; top: 150px; left: 200px; width: 40px; height: 40px; background: #3b82f6; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;" onclick="selectNumber(5)">5</div>
          <p id="trailMessage" style="text-align: center; margin-top: 20px;">Click numbers in order: 1 → 2 → 3 → 4 → 5</p>
        </div>
      `,
    },
  ]

  function updateProgress() {
    const progressFill = document.getElementById("progressFill")
    const currentTestSpan = document.getElementById("currentTest")

    if (progressFill) {
      progressFill.style.width = `${((currentTestIndex + 1) / tests.length) * 100}%`
    }
    if (currentTestSpan) {
      currentTestSpan.textContent = currentTestIndex + 1
    }
  }

  function loadTest() {
    const assessmentContent = document.getElementById("currentAssessment")
    const test = tests[currentTestIndex]

    if (assessmentContent && test) {
      assessmentContent.innerHTML = `
        <div class="task-card">
          <h3>Test ${currentTestIndex + 1}: ${test.name}</h3>
          <p>${test.description}</p>
          ${test.content}
          <div style="margin-top: 30px;">
            ${
              currentTestIndex < tests.length - 1
                ? '<button class="button" onclick="nextTest()">Next Test</button>'
                : '<button class="button" onclick="completeAssessment()">Complete Assessment</button>'
            }
          </div>
        </div>
      `

      // Initialize canvas for drawing test
      if (currentTestIndex === 1) {
        initializeCanvas()
      }
    }
  }

  window.nextTest = () => {
    if (currentTestIndex < tests.length - 1) {
      currentTestIndex++
      updateProgress()
      loadTest()
    }
  }

  window.completeAssessment = () => {
    showResults()
  }

  window.clearCanvas = () => {
    const canvas = document.getElementById("clockCanvas")
    if (canvas) {
      const ctx = canvas.getContext("2d")
      ctx.clearRect(0, 0, canvas.width, canvas.height)
    }
  }

  window.startTimer = () => {
    let timeLeft = 60
    const timerDisplay = document.getElementById("timer")
    const startBtn = document.getElementById("startTimerBtn")

    if (startBtn) startBtn.disabled = true

    const countdown = setInterval(() => {
      timeLeft--
      if (timerDisplay) timerDisplay.textContent = timeLeft

      if (timeLeft <= 0) {
        clearInterval(countdown)
        if (timerDisplay) timerDisplay.textContent = "Time's up!"
        if (startBtn) startBtn.disabled = false
      }
    }, 1000)
  }

  const trailSequence = []
  window.selectNumber = (num) => {
    const expectedNext = trailSequence.length + 1
    const messageEl = document.getElementById("trailMessage")

    if (num === expectedNext) {
      trailSequence.push(num)
      const numberEl = document.querySelector(`[onclick="selectNumber(${num})"]`)
      if (numberEl) numberEl.style.background = "#10b981"

      if (trailSequence.length === 5) {
        if (messageEl) messageEl.textContent = "Great! You completed the sequence correctly."
      } else {
        if (messageEl) messageEl.textContent = `Good! Now click ${trailSequence.length + 1}`
      }
    } else {
      if (messageEl) messageEl.textContent = `Try again. Click ${expectedNext} next.`
    }
  }

  function initializeCanvas() {
    const canvas = document.getElementById("clockCanvas")
    if (canvas) {
      const ctx = canvas.getContext("2d")
      let isDrawing = false

      canvas.addEventListener("mousedown", () => (isDrawing = true))
      canvas.addEventListener("mouseup", () => (isDrawing = false))
      canvas.addEventListener("mousemove", (e) => {
        if (!isDrawing) return

        const rect = canvas.getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top

        ctx.lineWidth = 2
        ctx.lineCap = "round"
        ctx.strokeStyle = "#3b82f6"

        ctx.lineTo(x, y)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(x, y)
      })
    }
  }

  updateProgress()
  loadTest()
}

function showResults() {
  showPage("resultsPage")

  setTimeout(() => {
    const riskScore = document.getElementById("riskScore")
    const riskLevel = document.getElementById("riskLevel")
    const recommendationsList = document.getElementById("recommendationsList")

    if (riskScore) riskScore.textContent = "7.2"
    if (riskLevel) riskLevel.textContent = "Low Risk - Normal cognitive function"

    if (recommendationsList) {
      recommendationsList.innerHTML = `
        <ul style="text-align: left; padding-left: 20px;">
          <li>Continue regular mental exercises</li>
          <li>Maintain social activities</li>
          <li>Annual screening recommended</li>
          <li>Consult healthcare provider if concerns arise</li>
        </ul>
      `
    }
  }, 1000)
}
