"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { getTranslation, formatTranslation } from "@/lib/i18n"

interface LanguageContextType {
  language: string
  setLanguage: (lang: string) => void
  t: (key: string, params?: { [key: string]: string | number }) => string
  isRTL: boolean
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

const RTL_LANGUAGES = ["arabic", "hebrew"]

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState("english")

  useEffect(() => {
    // Load saved language preference
    const savedLanguage = localStorage.getItem("cognitiveLanguage")
    if (savedLanguage) {
      setLanguageState(savedLanguage)
    }
  }, [])

  const setLanguage = (lang: string) => {
    setLanguageState(lang)
    localStorage.setItem("cognitiveLanguage", lang)

    // Update document direction for RTL languages
    document.documentElement.dir = RTL_LANGUAGES.includes(lang) ? "rtl" : "ltr"
    document.documentElement.lang = lang === "english" ? "en" : lang.substring(0, 2)
  }

  const t = (key: string, params?: { [key: string]: string | number }) => {
    if (params) {
      return formatTranslation(language, key, params)
    }
    return getTranslation(language, key)
  }

  const isRTL = RTL_LANGUAGES.includes(language)

  return <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
