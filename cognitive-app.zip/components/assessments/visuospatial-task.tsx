"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, RotateCcw } from "lucide-react"

interface VisuospatialTaskProps {
  onComplete: (data: any) => void
}

export function VisuospatialTask({ onComplete }: VisuospatialTaskProps) {
  const [phase, setPhase] = useState<"instructions" | "drawing">("instructions")
  const [targetTime, setTargetTime] = useState("10:30")
  const [startTime, setStartTime] = useState<Date | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [drawingData, setDrawingData] = useState<string>("")

  useEffect(() => {
    if (phase === "drawing") {
      setStartTime(new Date())
      setupCanvas()
    }
  }, [phase])

  const setupCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = 400
    canvas.height = 400

    // Set drawing styles
    ctx.strokeStyle = "#000000"
    ctx.lineWidth = 2
    ctx.lineCap = "round"
    ctx.lineJoin = "round"

    // Clear canvas with white background
    ctx.fillStyle = "#ffffff"
    ctx.fillRect(0, 0, canvas.width, canvas.height)
  }

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true)
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.beginPath()
    ctx.moveTo(x, y)
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.lineTo(x, y)
    ctx.stroke()
  }

  const stopDrawing = () => {
    setIsDrawing(false)
    const canvas = canvasRef.current
    if (canvas) {
      setDrawingData(canvas.toDataURL())
    }
  }

  const clearCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.fillStyle = "#ffffff"
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    setDrawingData("")
  }

  const handleComplete = () => {
    const endTime = new Date()
    const canvas = canvasRef.current
    const finalDrawingData = canvas ? canvas.toDataURL() : drawingData

    const data = {
      taskId: "visuospatial",
      startTime: startTime?.toISOString(),
      endTime: endTime.toISOString(),
      duration: startTime ? endTime.getTime() - startTime.getTime() : 0,
      targetTime,
      drawingData: finalDrawingData,
      completedAt: new Date().toISOString(),
    }
    onComplete(data)
  }

  return (
    <div className="max-w-4xl mx-auto">
      {phase === "instructions" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl">The Clock Draw</CardTitle>
            <CardDescription className="text-base">Visuospatial Function Assessment</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted/50 p-6 rounded-lg">
              <h3 className="font-semibold text-foreground mb-3">Instructions:</h3>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>You will draw a clock face on the canvas provided</li>
                <li>Include all 12 numbers in their correct positions</li>
                <li>
                  Draw the hands to show the time: <strong className="text-foreground">{targetTime}</strong>
                </li>
                <li>Take your time and draw as accurately as possible</li>
                <li>You can clear and restart if needed</li>
              </ol>
            </div>

            <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
              <p className="text-sm text-green-800">
                <strong>Remember:</strong> Draw a complete clock with numbers 1-12, and set the hands to show{" "}
                {targetTime}.
              </p>
            </div>

            <div className="text-center">
              <Button onClick={() => setPhase("drawing")} size="lg" className="px-8">
                Start Drawing
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {phase === "drawing" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl">Draw a Clock Showing {targetTime}</CardTitle>
            <CardDescription>Draw the clock face with numbers and hands</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="inline-block border-2 border-border rounded-lg p-4 bg-white">
                <canvas
                  ref={canvasRef}
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  className="border border-gray-300 cursor-crosshair"
                  style={{ touchAction: "none" }}
                />
              </div>
            </div>

            <div className="flex justify-center gap-4">
              <Button onClick={clearCanvas} variant="outline" className="flex items-center gap-2 bg-transparent">
                <RotateCcw className="w-4 h-4" />
                Clear & Restart
              </Button>
              <Button onClick={handleComplete} size="lg" className="px-8">
                Complete Task
              </Button>
            </div>

            <div className="bg-muted/50 p-4 rounded-lg text-center">
              <p className="text-sm text-muted-foreground">
                <strong>Target Time:</strong> {targetTime} (Ten thirty)
                <br />
                Make sure to include all numbers 1-12 and position the hands correctly
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
