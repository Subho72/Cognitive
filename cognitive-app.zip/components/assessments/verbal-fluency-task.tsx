"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { MessageSquare, Timer, Plus } from "lucide-react"

interface VerbalFluencyTaskProps {
  onComplete: (data: any) => void
}

const categories = [
  { id: "animals", name: "Animals", example: "dog, cat, elephant..." },
  { id: "fruits", name: "Fruits", example: "apple, banana, orange..." },
  { id: "colors", name: "Colors", example: "red, blue, green..." },
]

export function VerbalFluencyTask({ onComplete }: VerbalFluencyTaskProps) {
  const [phase, setPhase] = useState<"instructions" | "task" | "completed">("instructions")
  const [selectedCategory, setSelectedCategory] = useState(categories[0])
  const [timeLeft, setTimeLeft] = useState(60)
  const [isActive, setIsActive] = useState(false)
  const [words, setWords] = useState<string[]>([])
  const [currentWord, setCurrentWord] = useState("")
  const [startTime, setStartTime] = useState<Date | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((timeLeft) => timeLeft - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      setIsActive(false)
      setPhase("completed")
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, timeLeft])

  const startTask = () => {
    setStartTime(new Date())
    setPhase("task")
    setIsActive(true)
    setTimeLeft(60)
    setTimeout(() => {
      inputRef.current?.focus()
    }, 100)
  }

  const addWord = () => {
    if (currentWord.trim() && !words.includes(currentWord.trim().toLowerCase())) {
      setWords([...words, currentWord.trim().toLowerCase()])
      setCurrentWord("")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      addWord()
    }
  }

  const removeWord = (index: number) => {
    setWords(words.filter((_, i) => i !== index))
  }

  const handleComplete = () => {
    const endTime = new Date()

    // Analyze word clusters (basic grouping)
    const clusters = analyzeWordClusters(words, selectedCategory.id)

    const data = {
      taskId: "verbal-fluency",
      startTime: startTime?.toISOString(),
      endTime: endTime.toISOString(),
      duration: startTime ? endTime.getTime() - startTime.getTime() : 0,
      category: selectedCategory.id,
      words,
      totalWords: words.length,
      uniqueWords: words.length, // Already filtered for uniqueness
      clusters,
      completedAt: new Date().toISOString(),
    }
    onComplete(data)
  }

  const analyzeWordClusters = (wordList: string[], category: string) => {
    // Simple clustering logic based on category
    const clusters: { [key: string]: string[] } = {}

    if (category === "animals") {
      const pets = ["dog", "cat", "hamster", "rabbit", "bird", "fish"]
      const wild = ["lion", "tiger", "elephant", "giraffe", "zebra", "monkey"]
      const farm = ["cow", "pig", "chicken", "horse", "sheep", "goat"]

      clusters.pets = wordList.filter((word) => pets.some((pet) => word.includes(pet)))
      clusters.wild = wordList.filter((word) => wild.some((w) => word.includes(w)))
      clusters.farm = wordList.filter((word) => farm.some((f) => word.includes(f)))
      clusters.other = wordList.filter(
        (word) => !clusters.pets.includes(word) && !clusters.wild.includes(word) && !clusters.farm.includes(word),
      )
    } else {
      clusters.all = wordList
    }

    return clusters
  }

  return (
    <div className="max-w-4xl mx-auto">
      {phase === "instructions" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-purple-600" />
            </div>
            <CardTitle className="text-2xl">Verbal Fluency Challenge</CardTitle>
            <CardDescription className="text-base">Executive Function Assessment</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted/50 p-6 rounded-lg">
              <h3 className="font-semibold text-foreground mb-3">Instructions:</h3>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>
                  You have <strong className="text-foreground">60 seconds</strong> to name as many items as possible in
                  the given category
                </li>
                <li>Type each word and press Enter to add it to your list</li>
                <li>Try to think of as many different items as you can</li>
                <li>Duplicate words won't be counted</li>
                <li>The timer will start as soon as you begin</li>
              </ol>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-foreground">Select Category:</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {categories.map((category) => (
                  <Card
                    key={category.id}
                    className={`cursor-pointer transition-colors ${
                      selectedCategory.id === category.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => setSelectedCategory(category)}
                  >
                    <CardContent className="p-4 text-center">
                      <h4 className="font-medium text-foreground mb-2">{category.name}</h4>
                      <p className="text-sm text-muted-foreground">{category.example}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="bg-purple-50 border border-purple-200 p-4 rounded-lg">
              <p className="text-sm text-purple-800">
                <strong>Selected:</strong> {selectedCategory.name} - Name as many {selectedCategory.name.toLowerCase()}{" "}
                as you can in 60 seconds!
              </p>
            </div>

            <div className="text-center">
              <Button onClick={startTask} size="lg" className="px-8">
                <Timer className="w-5 h-5 mr-2" />
                Start Challenge
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {phase === "task" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Timer className="w-8 h-8 text-purple-600" />
            </div>
            <CardTitle className="text-2xl">Name {selectedCategory.name}</CardTitle>
            <CardDescription>
              Time remaining: <span className="font-bold text-2xl text-primary">{timeLeft}s</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={currentWord}
                onChange={(e) => setCurrentWord(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={`Type a ${selectedCategory.name.slice(0, -1).toLowerCase()}...`}
                className="flex-1"
                disabled={!isActive}
              />
              <Button onClick={addWord} disabled={!currentWord.trim() || !isActive}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-semibold text-foreground">Your Words ({words.length})</h3>
                <Badge variant="secondary">{words.length} words</Badge>
              </div>
              <div className="flex flex-wrap gap-2 min-h-[100px]">
                {words.map((word, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                    onClick={() => removeWord(index)}
                  >
                    {word} ×
                  </Badge>
                ))}
                {words.length === 0 && <p className="text-muted-foreground italic">Your words will appear here...</p>}
              </div>
            </div>

            <div className="text-center">
              <div className={`text-2xl font-bold ${timeLeft <= 10 ? "text-red-600" : "text-primary"}`}>
                {timeLeft}s remaining
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {phase === "completed" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl">Time's Up!</CardTitle>
            <CardDescription>
              Great job! You named {words.length} {selectedCategory.name.toLowerCase()}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted/50 p-4 rounded-lg">
              <h3 className="font-semibold text-foreground mb-3">Your Final List:</h3>
              <div className="flex flex-wrap gap-2">
                {words.map((word, index) => (
                  <Badge key={index} variant="secondary">
                    {word}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="text-center">
              <Button onClick={handleComplete} size="lg" className="px-8">
                Complete Task
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
