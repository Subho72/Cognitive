"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Brain, Play, Square, Mic, MicOff } from "lucide-react"

interface MemoryRecallTaskProps {
  onComplete: (data: any) => void
}

const sampleStory = {
  title: "The Village Market",
  content: `Maria walked to the village market on a sunny Tuesday morning. She needed to buy three items: fresh tomatoes, a loaf of bread, and some cheese for her family's dinner. At the market, she met her neighbor Carlos, who told her about the new bakery that opened last week. Maria bought the tomatoes from the first vendor, but the bread from the new bakery Carlos mentioned. She forgot to buy the cheese because she was distracted by a street musician playing guitar. On her way home, she remembered the cheese and returned to buy it from the dairy stand.`,
}

export function MemoryRecallTask({ onComplete }: MemoryRecallTaskProps) {
  const [phase, setPhase] = useState<"instructions" | "listening" | "recall" | "recording">("instructions")
  const [isPlaying, setIsPlaying] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [writtenRecall, setWrittenRecall] = useState("")
  const [startTime, setStartTime] = useState<Date | null>(null)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  useEffect(() => {
    if (phase === "listening") {
      setStartTime(new Date())
    }
  }, [phase])

  const playStory = () => {
    setIsPlaying(true)
    // Simulate story playback (in real app, this would use text-to-speech)
    setTimeout(() => {
      setIsPlaying(false)
      setPhase("recall")
    }, 30000) // 30 seconds for story
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/wav" })
        setAudioBlob(audioBlob)
        stream.getTracks().forEach((track) => track.stop())
      }

      mediaRecorder.start()
      setIsRecording(true)
    } catch (error) {
      console.error("Error accessing microphone:", error)
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const handleComplete = () => {
    const endTime = new Date()
    const data = {
      taskId: "memory-recall",
      startTime: startTime?.toISOString(),
      endTime: endTime.toISOString(),
      duration: startTime ? endTime.getTime() - startTime.getTime() : 0,
      writtenRecall,
      audioRecall: audioBlob ? "recorded" : null,
      storyContent: sampleStory.content,
      completedAt: new Date().toISOString(),
    }
    onComplete(data)
  }

  return (
    <div className="max-w-4xl mx-auto">
      {phase === "instructions" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl">The Storyteller</CardTitle>
            <CardDescription className="text-base">Memory & Recall Assessment</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted/50 p-6 rounded-lg">
              <h3 className="font-semibold text-foreground mb-3">Instructions:</h3>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>You will hear a short story about everyday activities</li>
                <li>Listen carefully and try to remember as many details as possible</li>
                <li>After the story ends, you'll retell it in your own words</li>
                <li>You can choose to write your response or record it by speaking</li>
                <li>Take your time - there's no rush</li>
              </ol>
            </div>

            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Tip:</strong> Focus on the main events, characters, and important details. Don't worry about
                remembering every single word.
              </p>
            </div>

            <div className="text-center">
              <Button onClick={() => setPhase("listening")} size="lg" className="px-8">
                <Play className="w-5 h-5 mr-2" />
                Start Story
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {phase === "listening" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl">Listen Carefully</CardTitle>
            <CardDescription>The story is playing. Pay attention to the details.</CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="bg-muted/50 p-8 rounded-lg">
              <div className="text-lg text-foreground mb-4 leading-relaxed">{sampleStory.content}</div>
            </div>

            <div className="flex justify-center">
              <Button onClick={playStory} disabled={isPlaying} size="lg" className="px-8">
                {isPlaying ? (
                  <>
                    <Square className="w-5 h-5 mr-2" />
                    Playing Story...
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Play Story Audio
                  </>
                )}
              </Button>
            </div>

            {!isPlaying && (
              <Button onClick={() => setPhase("recall")} variant="outline" className="mt-4">
                Skip to Recall (Read Only)
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {phase === "recall" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl">Now Retell the Story</CardTitle>
            <CardDescription>Share what you remember in your own words</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Write your response:</label>
                <Textarea
                  placeholder="Tell me what you remember about the story. Include as many details as you can recall..."
                  value={writtenRecall}
                  onChange={(e) => setWrittenRecall(e.target.value)}
                  className="min-h-32"
                />
              </div>

              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-4">Or record your response:</p>
                <div className="flex justify-center gap-4">
                  <Button onClick={() => setPhase("recording")} variant="outline" className="flex items-center gap-2">
                    <Mic className="w-4 h-4" />
                    Record Response
                  </Button>
                </div>
              </div>
            </div>

            <div className="text-center">
              <Button
                onClick={handleComplete}
                disabled={!writtenRecall.trim() && !audioBlob}
                size="lg"
                className="px-8"
              >
                Complete Task
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {phase === "recording" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mic className="w-8 h-8 text-red-600" />
            </div>
            <CardTitle className="text-2xl">Record Your Response</CardTitle>
            <CardDescription>Speak clearly and take your time</CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="bg-muted/50 p-6 rounded-lg">
              <p className="text-muted-foreground mb-4">
                Click the microphone button to start recording, then retell the story in your own words.
              </p>

              <div className="flex justify-center">
                {!isRecording ? (
                  <Button onClick={startRecording} size="lg" className="bg-red-600 hover:bg-red-700">
                    <Mic className="w-5 h-5 mr-2" />
                    Start Recording
                  </Button>
                ) : (
                  <Button onClick={stopRecording} size="lg" variant="destructive">
                    <MicOff className="w-5 h-5 mr-2" />
                    Stop Recording
                  </Button>
                )}
              </div>

              {isRecording && (
                <div className="mt-4">
                  <div className="w-4 h-4 bg-red-600 rounded-full mx-auto animate-pulse"></div>
                  <p className="text-sm text-red-600 mt-2">Recording in progress...</p>
                </div>
              )}
            </div>

            {audioBlob && (
              <div className="text-center">
                <p className="text-green-600 mb-4">✓ Recording completed</p>
                <Button onClick={handleComplete} size="lg" className="px-8">
                  Complete Task
                </Button>
              </div>
            )}

            <Button onClick={() => setPhase("recall")} variant="outline">
              Back to Written Response
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
