"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap, RotateCcw } from "lucide-react"

interface ProcessingSpeedTaskProps {
  onComplete: (data: any) => void
}

interface TrailItem {
  id: string
  x: number
  y: number
  isNumber: boolean
  value: string
  completed: boolean
}

export function ProcessingSpeedTask({ onComplete }: ProcessingSpeedTaskProps) {
  const [phase, setPhase] = useState<"instructions" | "task" | "completed">("instructions")
  const [trailItems, setTrailItems] = useState<TrailItem[]>([])
  const [currentTarget, setCurrentTarget] = useState<string>("1")
  const [sequence, setSequence] = useState<string[]>([])
  const [errors, setErrors] = useState<number>(0)
  const [startTime, setStartTime] = useState<Date | null>(null)
  const [completionTime, setCompletionTime] = useState<number>(0)
  const [clickSequence, setClickSequence] = useState<{ item: string; timestamp: number; correct: boolean }[]>([])

  const generateTrail = () => {
    const numbers = ["1", "2", "3", "4", "5", "6", "7", "8"]
    const letters = ["A", "B", "C", "D", "E", "F", "G", "H"]
    const items: TrailItem[] = []

    // Create alternating sequence: 1-A-2-B-3-C-4-D-5-E-6-F-7-G-8-H
    const targetSequence = []
    for (let i = 0; i < 8; i++) {
      targetSequence.push(numbers[i])
      targetSequence.push(letters[i])
    }
    setSequence(targetSequence)

    // Generate random positions for all items
    const allItems = [...numbers, ...letters]
    allItems.forEach((item, index) => {
      const isNumber = numbers.includes(item)
      items.push({
        id: `${item}-${index}`,
        x: Math.random() * 70 + 10, // 10-80% of container width
        y: Math.random() * 70 + 10, // 10-80% of container height
        isNumber,
        value: item,
        completed: false,
      })
    })

    setTrailItems(items)
  }

  const startTask = () => {
    setStartTime(new Date())
    setPhase("task")
    generateTrail()
    setCurrentTarget("1")
    setErrors(0)
    setClickSequence([])
  }

  const handleItemClick = (item: TrailItem) => {
    const timestamp = Date.now()
    const isCorrect = item.value === currentTarget

    setClickSequence((prev) => [
      ...prev,
      {
        item: item.value,
        timestamp,
        correct: isCorrect,
      },
    ])

    if (isCorrect) {
      // Mark item as completed
      setTrailItems((prev) => prev.map((i) => (i.value === item.value ? { ...i, completed: true } : i)))

      // Find next target in sequence
      const currentIndex = sequence.indexOf(currentTarget)
      if (currentIndex < sequence.length - 1) {
        setCurrentTarget(sequence[currentIndex + 1])
      } else {
        // Task completed
        const endTime = Date.now()
        const duration = startTime ? endTime - startTime.getTime() : 0
        setCompletionTime(duration)
        setPhase("completed")
      }
    } else {
      setErrors((prev) => prev + 1)
    }
  }

  const resetTask = () => {
    generateTrail()
    setCurrentTarget("1")
    setErrors(0)
    setClickSequence([])
    setStartTime(new Date())
  }

  const handleComplete = () => {
    const endTime = new Date()
    const data = {
      taskId: "processing-speed",
      startTime: startTime?.toISOString(),
      endTime: endTime.toISOString(),
      duration: completionTime || (startTime ? endTime.getTime() - startTime.getTime() : 0),
      errors,
      sequence,
      clickSequence,
      completed: phase === "completed",
      completedAt: new Date().toISOString(),
    }
    onComplete(data)
  }

  return (
    <div className="max-w-4xl mx-auto">
      {phase === "instructions" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-orange-600" />
            </div>
            <CardTitle className="text-2xl">Digital Trail Making</CardTitle>
            <CardDescription className="text-base">Attention & Processing Speed Assessment</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted/50 p-6 rounded-lg">
              <h3 className="font-semibold text-foreground mb-3">Instructions:</h3>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>You will see numbers (1-8) and letters (A-H) scattered on the screen</li>
                <li>
                  Click them in alternating order:{" "}
                  <strong className="text-foreground">
                    1 → A → 2 → B → 3 → C → 4 → D → 5 → E → 6 → F → 7 → G → 8 → H
                  </strong>
                </li>
                <li>Work as quickly and accurately as possible</li>
                <li>If you make a mistake, keep going - errors will be tracked</li>
                <li>The task is complete when you reach H</li>
              </ol>
            </div>

            <div className="bg-orange-50 border border-orange-200 p-4 rounded-lg">
              <p className="text-sm text-orange-800">
                <strong>Remember:</strong> Alternate between numbers and letters in sequence. Speed and accuracy are
                both important!
              </p>
            </div>

            <div className="text-center">
              <Button onClick={startTask} size="lg" className="px-8">
                <Zap className="w-5 h-5 mr-2" />
                Start Trail Making
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {phase === "task" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-orange-600" />
            </div>
            <CardTitle className="text-2xl">Click: {currentTarget}</CardTitle>
            <CardDescription>
              Errors: {errors} | Next in sequence:{" "}
              {sequence.slice(sequence.indexOf(currentTarget), sequence.indexOf(currentTarget) + 3).join(" → ")}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div
              className="relative bg-muted/20 rounded-lg border-2 border-dashed border-border"
              style={{ height: "500px" }}
            >
              {trailItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  className={`absolute w-12 h-12 rounded-full border-2 font-bold text-lg transition-all transform hover:scale-110 ${
                    item.completed
                      ? "bg-green-100 border-green-500 text-green-700"
                      : item.value === currentTarget
                        ? "bg-primary text-primary-foreground border-primary shadow-lg animate-pulse"
                        : item.isNumber
                          ? "bg-blue-100 border-blue-500 text-blue-700 hover:bg-blue-200"
                          : "bg-purple-100 border-purple-500 text-purple-700 hover:bg-purple-200"
                  }`}
                  style={{
                    left: `${item.x}%`,
                    top: `${item.y}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                  disabled={item.completed}
                >
                  {item.value}
                </button>
              ))}
            </div>

            <div className="flex justify-center gap-4">
              <Button onClick={resetTask} variant="outline" className="flex items-center gap-2 bg-transparent">
                <RotateCcw className="w-4 h-4" />
                Restart
              </Button>
            </div>

            <div className="bg-muted/50 p-4 rounded-lg text-center">
              <p className="text-sm text-muted-foreground">
                <strong>Current Target:</strong> {currentTarget} |<strong> Progress:</strong>{" "}
                {sequence.indexOf(currentTarget) + 1}/{sequence.length} |<strong> Errors:</strong> {errors}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {phase === "completed" && (
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl">Trail Completed!</CardTitle>
            <CardDescription>Excellent work! You completed the trail making task.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-muted/50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-primary">{(completionTime / 1000).toFixed(1)}s</div>
                <div className="text-sm text-muted-foreground">Completion Time</div>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-primary">{errors}</div>
                <div className="text-sm text-muted-foreground">Errors</div>
              </div>
            </div>

            <div className="text-center">
              <Button onClick={handleComplete} size="lg" className="px-8">
                Complete Task
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
