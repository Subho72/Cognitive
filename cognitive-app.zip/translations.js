const translations = {
  en: {
    "hero.title": "AI-Powered Cognitive Assessment",
    "hero.subtitle": "Quick and easy cognitive screening for early dementia detection",
    "hero.cta": "Start Assessment",
    "features.title": "Four Simple Tests",
    "features.memory.title": "Memory Test",
    "features.memory.description": "Story recall assessment",
    "features.visuospatial.title": "Drawing Test",
    "features.visuospatial.description": "Clock drawing task",
    "features.verbal.title": "Word Test",
    "features.verbal.description": "Verbal fluency check",
    "features.processing.title": "Speed Test",
    "features.processing.description": "Processing speed task",
    "info.title": "How It Works",
    "info.step1": "Set up your profile",
    "info.step2": "Complete 4 quick tests",
    "info.step3": "Get your results",
    "onboarding.title": "Quick Setup",
    "onboarding.age": "Age",
    "onboarding.gender": "Gender",
    "onboarding.male": "Male",
    "onboarding.female": "Female",
    "onboarding.other": "Other",
    "onboarding.education": "Education",
    "onboarding.primary": "Primary",
    "onboarding.secondary": "Secondary",
    "onboarding.higher": "Higher",
    "onboarding.continue": "Continue",
    "results.title": "Your Results",
    "results.calculating": "Calculating...",
    "results.recommendations": "Recommendations",
    "results.home": "Back to Home",
  },
  hi: {
    "hero.title": "एआई-संचालित संज्ञानात्मक मूल्यांकन",
    "hero.subtitle": "प्रारंभिक डिमेंशिया का पता लगाने के लिए त्वरित और आसान संज्ञानात्मक जांच",
    "hero.cta": "मूल्यांकन शुरू करें",
    "features.title": "चार सरल परीक्षण",
    "features.memory.title": "स्मृति परीक्षण",
    "features.memory.description": "कहानी याद करने का आकलन",
    "features.visuospatial.title": "चित्रकारी परीक्षण",
    "features.visuospatial.description": "घड़ी बनाने का कार्य",
    "features.verbal.title": "शब्द परीक्षण",
    "features.verbal.description": "मौखिक प्रवाहता जांच",
    "features.processing.title": "गति परीक्षण",
    "features.processing.description": "प्रसंस्करण गति कार्य",
    "info.title": "यह कैसे काम करता है",
    "info.step1": "अपनी प्रोफ़ाइल सेट करें",
    "info.step2": "4 त्वरित परीक्षण पूरे करें",
    "info.step3": "अपने परिणाम प्राप्त करें",
    "onboarding.title": "त्वरित सेटअप",
    "onboarding.age": "आयु",
    "onboarding.gender": "लिंग",
    "onboarding.male": "पुरुष",
    "onboarding.female": "महिला",
    "onboarding.other": "अन्य",
    "onboarding.education": "शिक्षा",
    "onboarding.primary": "प्राथमिक",
    "onboarding.secondary": "माध्यमिक",
    "onboarding.higher": "उच्च",
    "onboarding.continue": "जारी रखें",
    "results.title": "आपके परिणाम",
    "results.calculating": "गणना कर रहे हैं...",
    "results.recommendations": "सिफारिशें",
    "results.home": "होम पर वापस जाएं",
  },
  bn: {
    "hero.title": "AI-চালিত জ্ঞানীয় মূল্যায়ন",
    "hero.subtitle": "প্রাথমিক ডিমেনশিয়া সনাক্তকরণের জন্য দ্রুত এবং সহজ জ্ঞানীয় স্ক্রিনিং",
    "hero.cta": "মূল্যায়ন শুরু করুন",
  },
  te: {
    "hero.title": "AI-ఆధారిత అభిజ్ఞా మూల্యాంకనం",
    "hero.subtitle": "ప్రారంభ డిమెన్షియా గుర్తింపు కోసం త్వరిత మరియు సులభమైన అభిజ్ఞా స్క్రీనింగ్",
    "hero.cta": "మూల్యాంకనను ప్రారంభించండి",
  },
  mr: {
    "hero.title": "AI-आधारित संज्ञानात्मक मूल्यांकन",
    "hero.subtitle": "लवकर डिमेंशिया शोधासाठी जलद आणि सोपी संज्ञानात्मक तपासणी",
    "hero.cta": "मूल्यांकन सुरू करा",
  },
  ta: {
    "hero.title": "AI-அடிப்படையிலான அறிவாற்றல் மதிப்பீடு",
    "hero.subtitle": "ஆரம்பகால டிமென்ஷியா கண்டறிதலுக்கான விரைவான மற்றும் எளிதான அறிவாற்றல் ஸ்கிரீனிங்",
    "hero.cta": "மதிப்பீட்டைத் தொடங்கவும்",
  },
}

function translatePage(language) {
  const elements = document.querySelectorAll("[data-translate]")
  elements.forEach((element) => {
    const key = element.getAttribute("data-translate")
    if (translations[language] && translations[language][key]) {
      element.textContent = translations[language][key]
    } else if (translations.en[key]) {
      // Fallback to English if translation not available
      element.textContent = translations.en[key]
    }
  })

  document.documentElement.lang = language
}
